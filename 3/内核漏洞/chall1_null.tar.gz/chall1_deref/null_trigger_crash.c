#define _GNU_SOURCE

int main(void)
{
	int ret = EXIT_FAILURE;

	/* Use one specific order to trigger Null Pointer Dereference */
	/* Fill your code here */

	return ret;
}
