#define _GNU_SOURCE

int main(void)
{
	int ret = EXIT_FAILURE;

	/* Fill all the operations in the kernel module */
	/* Fill your code here */

	return ret;
}
